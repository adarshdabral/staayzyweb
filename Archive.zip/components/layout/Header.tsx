"use client";

import Link from "next/link";
import { useAuthStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { User, LogOut } from "lucide-react";

export default function Header() {
  const router = useRouter();
  const { user, token, logout, hydrated } = useAuthStore();

  // 🚨 Prevent hydration mismatch
  if (!hydrated) return null;

  const isAuthenticated = !!token;

  return (
    <header className="border-b bg-white">
      <div className="container mx-auto px-4 py-4 flex justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white font-bold">
            S
          </div>
          <span className="text-2xl font-bold text-primary">Staayzy</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/">Home</Link>

          {isAuthenticated && user?.role === "tenant" && (
            <>
              <Link href="/tenant">Find Rooms</Link>
              <Link href="/tenant/dashboard">Dashboard</Link>
            </>
          )}

          {isAuthenticated && user?.role === "owner" && (
            <>
              <Link href="/owner">My Properties</Link>
              <Link href="/owner/dashboard">Dashboard</Link>
            </>
          )}

          {isAuthenticated && user?.role === "admin" && (
            <Link href="/admin/dashboard">Admin Dashboard</Link>
          )}
        </nav>

        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <>
              <div className="flex items-center gap-2">
                <User className="h-5 w-5" />
                <span>{user?.name}</span>
              </div>
              <Button
                variant="outline"
                onClick={() => {
                  logout();
                  router.push("/");
                }}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </>
          ) : (
            <>
              <Button onClick={() => router.push("/auth/login")}>Login</Button>
              <Button onClick={() => router.push("/auth/register")}>
                Sign Up
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
