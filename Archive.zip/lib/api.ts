import axios, {
  AxiosError,
  AxiosResponse,
  InternalAxiosRequestConfig,
} from "axios";
import { useAuthStore } from "@/lib/store";

/* ──────────────────────────────
   BASE URL
────────────────────────────── */
const RAW_API_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5001";

const API_BASE_URL = `${RAW_API_URL}/api`;

if (process.env.NODE_ENV === "development") {
  console.log("[API] Base URL:", API_BASE_URL);
}

/* ──────────────────────────────
   AXIOS INSTANCE
────────────────────────────── */
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

/* ──────────────────────────────
   REQUEST INTERCEPTOR
────────────────────────────── */
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = useAuthStore.getState().token;

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    if (process.env.NODE_ENV === "development") {
      console.log(
        `[API REQUEST] ${config.method?.toUpperCase()} ${config.url}`
      );
      if (config.data) {
        console.log("[API REQUEST] Payload:", config.data);
      }
    }

    return config;
  },
  (error: AxiosError) => {
    console.error("[API REQUEST ERROR]", error);
    return Promise.reject(error);
  }
);

/* ──────────────────────────────
   RESPONSE INTERCEPTOR
────────────────────────────── */
api.interceptors.response.use(
  (response: AxiosResponse) => {
    if (process.env.NODE_ENV === "development") {
      console.log(
        `[API RESPONSE] ${response.status} ${response.config.url}`,
        response.data
      );
    }
    return response;
  },
  (error: AxiosError) => {
    if (process.env.NODE_ENV === "development") {
      console.error("[API RESPONSE ERROR]");
      console.error("URL:", error.config?.url);
      console.error("Status:", error.response?.status);
      console.error("Response:", error.response?.data);
    }

    // ❗ DO NOT REDIRECT HERE
    return Promise.reject(error);
  }
);

export default api;
