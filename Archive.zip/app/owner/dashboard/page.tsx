"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Home,
  Calendar,
  Users,
  DollarSign,
  Eye,
  Edit,
  Check,
  X,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";
import { useAuthStore } from "@/lib/store";
import { useToast } from "@/lib/hooks/use-toast";

export default function OwnerDashboard() {
  const router = useRouter();
  const { user, token } = useAuthStore();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  /* ──────────────────────────────
     AUTH + ROLE GUARD
  ─────────────────────────────── */
  useEffect(() => {
    if (!token) {
      router.replace("/auth/login");
      return;
    }

    if (user && user.role !== "owner") {
      router.replace("/");
    }
  }, [token, user, router]);

  // ⛔ Block render & API calls until auth is ready
  if (!token || !user) return null;

  /* ──────────────────────────────
     DATA FETCHING (SAFE)
  ─────────────────────────────── */
  const { data: properties = [] } = useQuery({
    queryKey: ["owner-properties"],
    enabled: !!token,
    queryFn: async () => {
      const res = await api.get("/properties?owner=me");
      return res.data;
    },
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["owner-bookings"],
    enabled: !!token,
    queryFn: async () => {
      const res = await api.get("/bookings");
      return res.data;
    },
  });

  /* ──────────────────────────────
     MUTATIONS
  ─────────────────────────────── */
  const updateBookingStatusMutation = useMutation({
    mutationFn: async ({
      bookingId,
      status,
    }: {
      bookingId: string;
      status: string;
    }) => api.put(`/bookings/${bookingId}/status`, { status }),

    onSuccess: () => {
      toast({ title: "Booking status updated" });
      queryClient.invalidateQueries({ queryKey: ["owner-bookings"] });
    },

    onError: (error: any) => {
      toast({
        title: "Error",
        description:
          error.response?.data?.message || "Failed to update booking",
        variant: "destructive",
      });
    },
  });

  /* ──────────────────────────────
     STATS
  ─────────────────────────────── */
  const totalProperties = properties.length;
  const approvedProperties = properties.filter(
    (p: any) => p.status === "approved"
  ).length;
  const pendingProperties = properties.filter(
    (p: any) => p.status === "pending"
  ).length;

  const totalBookings = bookings.length;
  const pendingBookings = bookings.filter(
    (b: any) => b.status === "pending"
  ).length;

  const totalRevenue = bookings
    .filter((b: any) => b.status === "approved")
    .reduce((sum: number, b: any) => sum + (b.rent || 0), 0);

  /* ──────────────────────────────
     UI
  ─────────────────────────────── */
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Owner Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user.name}!</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Properties"
            value={totalProperties}
            subtitle={`${approvedProperties} approved, ${pendingProperties} pending`}
            icon={<Home />}
          />
          <StatCard
            title="Total Bookings"
            value={totalBookings}
            subtitle={`${pendingBookings} pending approval`}
            icon={<Calendar />}
          />
          <StatCard
            title="Total Revenue"
            value={`₹${totalRevenue.toLocaleString()}`}
            subtitle="From approved bookings"
            icon={<DollarSign />}
          />
          <StatCard
            title="Interested Tenants"
            value={totalBookings}
            subtitle="Booking requests"
            icon={<Users />}
          />
        </div>

        <Tabs defaultValue="properties" className="space-y-6">
          <TabsList>
            <TabsTrigger value="properties">My Properties</TabsTrigger>
            <TabsTrigger value="bookings">Booking Requests</TabsTrigger>
            <TabsTrigger value="earnings">Earnings</TabsTrigger>
          </TabsList>

          {/* Properties */}
          <TabsContent value="properties">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">Your Properties</h2>
              <Link href="/owner/properties/new">
                <Button>Add New Property</Button>
              </Link>
            </div>

            {properties.length === 0 ? (
              <EmptyCard text="No properties yet">
                <Link href="/owner/properties/new">
                  <Button>Add Your First Property</Button>
                </Link>
              </EmptyCard>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {properties.map((property: any) => (
                  <PropertyCard key={property._id} property={property} />
                ))}
              </div>
            )}
          </TabsContent>

          {/* Bookings */}
          <TabsContent value="bookings">
            {bookings.length === 0 ? (
              <EmptyCard text="No booking requests yet" />
            ) : (
              bookings.map((booking: any) => (
                <BookingCard
                  key={booking._id}
                  booking={booking}
                  onUpdate={updateBookingStatusMutation.mutate}
                  loading={updateBookingStatusMutation.isPending}
                />
              ))
            )}
          </TabsContent>

          {/* Earnings */}
          <TabsContent value="earnings">
            <Card>
              <CardHeader>
                <CardTitle>Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary">
                  ₹{totalRevenue.toLocaleString()}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

/* ──────────────────────────────
   SMALL COMPONENTS
────────────────────────────── */
function StatCard({ title, value, subtitle, icon }: any) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardContent>
    </Card>
  );
}

function EmptyCard({ text, children }: any) {
  return (
    <Card>
      <CardContent className="py-12 text-center">
        <p className="text-gray-600 mb-4">{text}</p>
        {children}
      </CardContent>
    </Card>
  );
}

function PropertyCard({ property }: any) {
  return (
    <Card>
      {property.images?.[0] && (
        <img
          src={property.images[0]}
          alt={property.name}
          className="h-48 w-full object-cover"
        />
      )}
      <CardHeader>
        <CardTitle>{property.name}</CardTitle>
        <CardDescription>
          {property.nearestCollege} • {property.distanceFromCollege} km
        </CardDescription>
      </CardHeader>
      <CardContent className="flex gap-2">
        <Link href={`/properties/${property._id}`} className="flex-1">
          <Button variant="outline" className="w-full">
            <Eye className="mr-2 h-4 w-4" /> View
          </Button>
        </Link>
        <Link href={`/owner/properties/${property._id}`} className="flex-1">
          <Button variant="outline" className="w-full">
            <Edit className="mr-2 h-4 w-4" /> Edit
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

function BookingCard({ booking, onUpdate, loading }: any) {
  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle>{booking.property?.name}</CardTitle>
      </CardHeader>
      <CardContent className="flex justify-between items-center">
        <span>{booking.status.toUpperCase()}</span>
        {booking.status === "pending" && (
          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => onUpdate({ bookingId: booking._id, status: "approved" })}
              disabled={loading}
            >
              <Check className="mr-1 h-4 w-4" /> Approve
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => onUpdate({ bookingId: booking._id, status: "rejected" })}
              disabled={loading}
            >
              <X className="mr-1 h-4 w-4" /> Reject
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
