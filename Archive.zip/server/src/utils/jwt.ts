// import jwt from "jsonwebtoken";

// const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
// const JWT_EXPIRE = process.env.JWT_EXPIRE || "7d";

// export const generateToken = (userId: string): string => {
//   return jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRE });
// };

// export const verifyToken = (token: string): any => {
//   return jwt.verify(token, JWT_SECRET);
// };

import jwt from "jsonwebtoken";

export const generateToken = (userId: string): string => {
  const JWT_SECRET = process.env.JWT_SECRET;

  if (!JWT_SECRET) {
    throw new Error("JWT_SECRET is not defined");
  }

  return jwt.sign(
    { userId },
    JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE || "7d" }
  );
};


