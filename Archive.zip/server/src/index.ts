import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";

// Routes
import authRoutes from "./routes/auth";
import propertyRoutes from "./routes/properties";
import bookingRoutes from "./routes/bookings";
import reviewRoutes from "./routes/reviews";
import complaintRoutes from "./routes/complaints";
import wishlistRoutes from "./routes/wishlist";
import adminRoutes from "./routes/admin";
import userRoutes from "./routes/users";
import uploadRoutes from "./routes/uploads";

/* ──────────────────────────────
   ENV SETUP
────────────────────────────── */
dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 5001;

console.log("[BOOT] Server starting on port", PORT);

/* ──────────────────────────────
   CORS (FINAL, SAFE CONFIG)
────────────────────────────── */
const FRONTEND_URL = process.env.CLIENT_URL || "http://localhost:3000";

app.use(
  cors({
    origin: FRONTEND_URL,
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// ✅ Explicit preflight handling
app.options("*", cors());

console.log("[CORS] Allowed origin:", FRONTEND_URL);

/* ──────────────────────────────
   BODY PARSERS
────────────────────────────── */
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* ──────────────────────────────
   REQUEST LOGGER
────────────────────────────── */
app.use((req, _res, next) => {
  console.log(`[REQUEST] ${req.method} ${req.originalUrl}`);
  next();
});

/* ──────────────────────────────
   MONGODB CONNECTION
────────────────────────────── */
const MONGODB_URI =
  process.env.MONGODB_URI || "mongodb://localhost:27017/staayzy";

mongoose
  .connect(MONGODB_URI)
  .then(() => console.log("[DB] MongoDB connected"))
  .catch((err) => console.error("[DB] MongoDB connection error:", err));

/* ──────────────────────────────
   ROUTES
────────────────────────────── */
app.use("/api/auth", authRoutes);
app.use("/api/properties", propertyRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/complaints", complaintRoutes);
app.use("/api/wishlist", wishlistRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/users", userRoutes);
app.use("/api/uploads", uploadRoutes);

/* ──────────────────────────────
   HEALTH CHECK
────────────────────────────── */
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    dbState: mongoose.connection.readyState,
  });
});

/* ──────────────────────────────
   GLOBAL ERROR HANDLER
────────────────────────────── */
app.use((err: any, _req: any, res: any, _next: any) => {
  console.error("[ERROR]", err);
  res.status(500).json({ message: "Internal server error" });
});

/* ──────────────────────────────
   SERVER START
────────────────────────────── */
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
