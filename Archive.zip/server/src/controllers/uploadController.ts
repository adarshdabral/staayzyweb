import { Response } from "express";
import { AuthRequest } from "../middleware/auth";
import cloudinary from "../config/cloudinary";

// Upload images (multipart/form-data) and return array of URLs
export const uploadImages = async (req: AuthRequest, res: Response) => {
  try {
    const files: any[] = (req.files as any) || [];

    if (!files || files.length === 0) {
      return res.status(400).json({ message: "No files uploaded" });
    }

    // Upload each file buffer to Cloudinary as data URI to avoid extra deps
    const uploadPromises = files.map((file) => {
      const dataUri = `data:${file.mimetype};base64,${file.buffer.toString("base64")}`;
      return cloudinary.uploader.upload(dataUri, { folder: "staayzy" });
    });

    const results = await Promise.all(uploadPromises);
    const urls = results.map((r: any) => r.secure_url || r.url);

    res.json({ urls });
  } catch (error) {
    console.error("Upload images error:", error);
    res.status(500).json({ message: "Failed to upload images" });
  }
};

export default { uploadImages };
