import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import User from "../models/User";

export interface AuthRequest extends Request {
  user?: any;
}

/* ──────────────────────────────
   AUTHENTICATION MIDDLEWARE
────────────────────────────── */
export const authenticate = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  /* ✅ Allow CORS preflight */
  if (req.method === "OPTIONS") {
    return next();
  }

  try {
    if (process.env.NODE_ENV === "development") {
      console.log("[AUTH] Request:", req.method, req.originalUrl);
    }

    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      if (process.env.NODE_ENV === "development") {
        console.warn("[AUTH] Missing or malformed Authorization header");
      }
      return res.status(401).json({ message: "Authentication required" });
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const JWT_SECRET = process.env.JWT_SECRET;
    if (!JWT_SECRET) {
      throw new Error("JWT_SECRET is not defined");
    }

    if (process.env.NODE_ENV === "development") {
      console.log("[AUTH] Verifying JWT...");
    }

    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };

    if (process.env.NODE_ENV === "development") {
      console.log("[AUTH] Token valid for user:", decoded.userId);
    }

    const user = await User.findById(decoded.userId).select("-password");

    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    req.user = user;
    next();
  } catch (error: any) {
    console.error("[AUTH] Authentication failed:", error.message);
    return res.status(401).json({ message: "Invalid or expired token" });
  }
};

/* ──────────────────────────────
   AUTHORIZATION (ROLE CHECK)
────────────────────────────── */
export const authorize = (...roles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    /* ✅ Allow preflight */
    if (req.method === "OPTIONS") {
      return next();
    }

    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!roles.includes(req.user.role)) {
      if (process.env.NODE_ENV === "development") {
        console.warn(
          "[AUTHZ] Access denied:",
          req.user.role,
          "required:",
          roles
        );
      }
      return res
        .status(403)
        .json({ message: "Access denied. Insufficient permissions." });
    }

    next();
  };
};
