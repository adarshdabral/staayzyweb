import express from "express";
import {
  createProperty,
  addRoom,
  getProperties,
  getPropertyById,
  updateProperty,
  deleteProperty,
} from "../controllers/propertyController";
import { authenticate, authorize } from "../middleware/auth";

const router = express.Router();

router.get("/", getProperties);
router.get("/:id", getPropertyById);

router.post(
  "/",
  authenticate,
  authorize("owner", "admin"),
  createProperty
);
router.post(
  "/:propertyId/rooms",
  authenticate,
  authorize("owner", "admin"),
  addRoom
);
router.put(
  "/:id",
  authenticate,
  authorize("owner", "admin"),
  updateProperty
);
router.delete(
  "/:id",
  authenticate,
  authorize("owner", "admin"),
  deleteProperty
);

export default router;


