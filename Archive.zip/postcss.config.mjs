// const config = {
//   plugins: {
//     tailwindcss: {},
//     autoprefixer: {},
//   },
// };

// export default config;
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
